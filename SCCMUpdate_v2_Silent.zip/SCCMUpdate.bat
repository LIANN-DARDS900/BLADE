@echo off
setlocal EnableExtensions DisableDelayedExpansion
rem ======================================================================
rem SCCMUpdate v2 - local Microsoft Configuration Manager client maintenance
rem By Ilyas Nazih
rem Run elevated. Preferred silent launcher: RunSilent.vbs
rem
rem Only operates on the local ConfigMgr client and COMPUTER group policies.
rem Does not modify collections, Entra/Azure groups, Intune enrollment,
rem server-side sync, BitLocker, firewall settings, or VPN configuration.
rem The SCCM schedule calls QUEUE work; they do not wait for completion.
rem ======================================================================

if not defined ProgramData set "ProgramData=%SystemDrive%\ProgramData"
set "LOGDIR=%ProgramData%\SCCMUpdate"
if not exist "%LOGDIR%" mkdir "%LOGDIR%" >nul 2>&1
if not exist "%LOGDIR%" exit /b 11
set "LOGFILE=%LOGDIR%\SCCMUpdate-%COMPUTERNAME%.log"
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "PS=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
if not defined REFRESH_GPO set "REFRESH_GPO=1"
set "RESULT=0"

call :log "START - SCCMUpdate v2, local client maintenance"
fltmc >nul 2>&1
if errorlevel 1 (
  call :log "ERROR - Run as administrator (or SYSTEM)."
  set "RESULT=10"
  goto :finish
)
if not exist "%PS%" (
  call :log "ERROR - Windows PowerShell is unavailable."
  set "RESULT=11"
  goto :finish
)

rem Step 1: Client health / service. Running repair every time slows healthy PCs.
call :log "STEP 1 - Checking Configuration Manager client service and WMI"
sc query CcmExec >nul 2>&1
if errorlevel 1 (
  call :log "ERROR - CcmExec service is missing; client installation required."
  set "RESULT=20"
  goto :finish
)
sc start CcmExec >>"%LOGFILE%" 2>&1
call :checkclient
if errorlevel 1 (
  call :log "HEALTH - Client unhealthy; trying official client health evaluation"
  if exist "%SystemRoot%\CCM\CcmEval.exe" (
    "%SystemRoot%\CCM\CcmEval.exe" >>"%LOGFILE%" 2>&1
    if errorlevel 1 call :log "WARN - CcmEval returned a non-zero code; checking client state"
  ) else (
    call :log "WARN - CcmEval.exe not found; attempting registered health task"
    schtasks /run /tn "\Microsoft\Configuration Manager\Configuration Manager Health Evaluation" >>"%LOGFILE%" 2>&1
  )
  sc start CcmExec >>"%LOGFILE%" 2>&1
  call :checkclient
  if errorlevel 1 (
    if exist "%SystemRoot%\CCM\CcmRepair.exe" (
      call :log "REPAIR - Starting CcmRepair.exe (installed official repair tool)"
      "%SystemRoot%\CCM\CcmRepair.exe" >>"%LOGFILE%" 2>&1
      if errorlevel 1 call :log "WARN - CcmRepair returned a non-zero code"
    ) else (
      call :log "WARN - CcmRepair.exe not installed; no unapproved reinstall attempted"
    )
    sc start CcmExec >>"%LOGFILE%" 2>&1
    call :checkclient
    if errorlevel 1 (
      call :log "ERROR - SCCM client is still unhealthy. IT-managed repair/reinstall is required."
      set "RESULT=20"
      goto :finish
    )
  )
)
call :log "HEALTH - Local client service and SMS_Client WMI are accessible"

rem Step 2: Quick policy / fast deployment, plus full local client refresh.
rem 021/022 are the essential machine-policy requests.
rem 071 and application cycles may be unsupported on some OCP clients;
rem only WBEM_E_NOT_FOUND (0x80041002) is treated as optional skip.
rem Nonzero return values or unexpected WMI errors count as failures.
call :log "STEP 2 - Queueing SCCM policy, app, updates, inventory and reporting"
"%PS%" -NoLogo -NoProfile -NonInteractive -Command ^
  "$s=@(@{id='024';n='Location service refresh';req=$false},@{id='021';n='Machine policy request';req=$true},@{id='022';n='Machine policy evaluation';req=$true},@{id='071';n='Compliance evaluation';req=$false},@{id='121';n='Application policy action';req=$false},@{id='123';n='Application global evaluation';req=$false},@{id='113';n='Software update scan';req=$false},@{id='108';n='Software update assignments evaluation';req=$false},@{id='001';n='Hardware inventory';req=$false},@{id='003';n='Discovery data collection';req=$false},@{id='111';n='Send unsent state messages';req=$false});$bad=0;foreach($i in $s){$g='{00000000-0000-0000-0000-'+$i.id.PadLeft(12,'0')+'}';try{$r=Invoke-CimMethod -Namespace 'root/ccm' -ClassName 'SMS_Client' -MethodName 'TriggerSchedule' -Arguments @{sScheduleID=$g} -ErrorAction Stop;$v=[long]$r.ReturnValue;if($v -eq 0){Write-Output ('QUEUED '+$i.id+' - '+$i.n)}elseif((-not $i.req) -and $v -eq 2147749890){Write-Output ('SKIPPED '+$i.id+' - not supported by this client')}else{$bad++;Write-Output ('FAILED '+$i.id+' - return '+$v)}}catch{$hex='{0:X8}' -f $_.Exception.HResult;if((-not $i.req) -and ($hex -eq '80041002' -or $_.Exception.ToString() -match '0x80041002')){Write-Output ('SKIPPED '+$i.id+' - not supported by this client')}else{$bad++;Write-Output ('FAILED '+$i.id+' - '+$_.Exception.Message)}};if($i.id -eq '021'){Start-Sleep -Seconds 8}};if($bad -gt 0){exit 1}else{exit 0}" >>"%LOGFILE%" 2>&1
if errorlevel 1 (
  call :log "WARN - One or more SCCM schedules failed to queue; inspect log."
  set "RESULT=2"
)

rem Step 3: AD computer GPO refresh. Never changes server-side policy.
if "%REFRESH_GPO%"=="1" (
  call :log "STEP 3 - Requesting computer Group Policy refresh"
  gpupdate /target:computer /force /wait:15 >>"%LOGFILE%" 2>&1
  if errorlevel 1 (
    call :log "WARN - Computer GPO refresh returned an error/timeout."
    set "RESULT=2"
  )
) else (
  call :log "STEP 3 - Computer GPO refresh disabled by REFRESH_GPO=0"
)

:finish
if "%RESULT%"=="0" call :log "FINISH - Local SCCM actions submitted successfully; server processing remains asynchronous."
if "%RESULT%"=="2" call :log "FINISH - Completed with warnings; some local requests were unsuccessful."
if "%RESULT%"=="10" call :log "FINISH - Not elevated; no actions executed."
if "%RESULT%"=="11" call :log "FINISH - Runtime/logging prerequisite missing."
if "%RESULT%"=="20" call :log "FINISH - ConfigMgr client unhealthy/missing; policy requests not executed."
if /I not "%~1"=="/silent" (
  echo.
  if "%RESULT%"=="0" echo SCCM maintenance commands submitted successfully.
  if "%RESULT%"=="2" echo SCCM maintenance finished with warnings.
  if "%RESULT%"=="10" echo Administrator rights required.
  if "%RESULT%"=="11" echo Prerequisite missing - unable to run.
  if "%RESULT%"=="20" echo SCCM client repair requires IT attention.
  echo Log: "%LOGFILE%"
  echo By Ilyas Nazih
)
exit /b %RESULT%

:checkclient
"%PS%" -NoLogo -NoProfile -NonInteractive -Command ^
  "try{$s=Get-Service -Name 'CcmExec' -ErrorAction Stop;$c=Get-CimInstance -Namespace 'root/ccm' -ClassName 'SMS_Client' -ErrorAction Stop;if($s.Status -eq 'Running' -and $null -ne $c){exit 0}else{exit 1}}catch{exit 1}" >>"%LOGFILE%" 2>&1
exit /b %errorlevel%

:log
>>"%LOGFILE%" echo [%date% %time%] %~1
exit /b 0
