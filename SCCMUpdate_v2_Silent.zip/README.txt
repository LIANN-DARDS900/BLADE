SCCMUpdate v2 - Silent ConfigMgr maintenance
By Ilyas Nazih

PURPOSE
Run the local SCCM / Microsoft Configuration Manager client actions technicians
normally start through Fast Deployment and SCCM Refresh, without requiring Ethernet
instead of an already-working corporate VPN.

HOW TO RUN
1. Extract the 3 files into the same folder on an authorized test laptop.
2. Double-click RunSilent.vbs. Accept Windows UAC if prompted.
3. Wait while it runs hidden. A native Windows result message appears at the end.
4. Review the machine in the usual OCP tools and the log if needed.
   Log folder: C:\ProgramData\SCCMUpdate\

When Windows Script Host is blocked by OCP security policy, open Command Prompt
as Administrator and run SCCMUpdate.bat directly; it will display an exit summary
in the command window. Do not change security policies to permit WSH.

ACTIONS (in execution order)
  1. Administrator check; verify/start CcmExec; check root\ccm SMS_Client WMI.
     If unhealthy: CcmEval.exe / scheduled health evaluation if available;
     if still unhealthy, CcmRepair.exe when installed. If the repair binary
     is missing, report that an IT-managed client repair is required.
     No automatic uninstall, reinstall or ccmsetup invocation.
  2. SMS_Client.TriggerSchedule requests:
     024 Location service refresh
     021 Machine policy assignments request (required)
     022 Machine policy evaluation (required)
     071 Compliance settings evaluation (optional)
     121 Application manager policy (optional)
     123 Application manager global evaluation (optional)
     113 Software update scan (optional)
     108 Software update assignments evaluation (optional)
     001 Hardware inventory (optional)
     003 Data discovery (optional)
     111 Send unsent state messages (optional)
     Optional schedules returning exactly 0x80041002 are SKIPPED; other errors
     are recorded as a warning.
  3. gpupdate /target:computer /force /wait:15
     To turn this off, set REFRESH_GPO=0 in the BAT or parent environment.

SUCCESS WINDOW
Only displayed when the local SCCM calls were successfully submitted,
with no other command errors. SCCM policy/application/inventory processing may
continue in the background; this script does NOT confirm server-side sync.

WARNINGS / FAILURE
A yellow warning is shown if some calls failed. A red error is shown when
administrator rights are missing, the ConfigMgr client cannot be repaired,
or a prerequisite is missing. Review the log before using the laptop.

BOUNDARIES
No VPN/Ethernet validation, no BitLocker modifications/verification,
no Intune enrollment, no Azure/Entra group or server-side SCCM collection
changes, no forced software installs, no automatic reboot, no changes to
Windows execution policy, and no bypasses of corporate security controls.

PILOT FIRST
Requires Windows PowerShell 5.1 and administrator permissions.
Test on an approved spare OCP laptop (Ethernet and VPN if relevant).
Do not mass-deploy without IT approval and checking actual outcomes.
