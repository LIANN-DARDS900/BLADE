Option Explicit
' SCCMUpdate v2 - silent elevated launcher and completion notification.
' By Ilyas Nazih. One UAC consent may be required on first launch.
Dim sh, app, fso, q, cmd, admin, bat, rc, title, msg, style
Set sh = CreateObject("WScript.Shell")
Set app = CreateObject("Shell.Application")
Set fso = CreateObject("Scripting.FileSystemObject")
q = Chr(34)

' Elevation is required for CcmExec and client health actions.
' Runas may display the standard Windows UAC prompt; it is not bypassed.
cmd = q & sh.ExpandEnvironmentStrings("%ComSpec%") & q & " /d /c " & q & "fltmc >nul 2>&1" & q
admin = sh.Run(cmd, 0, True)
If admin <> 0 Then
    On Error Resume Next
    app.ShellExecute sh.ExpandEnvironmentStrings("%SystemRoot%\System32\wscript.exe"), _
        q & WScript.ScriptFullName & q & " /elevated", _
        fso.GetParentFolderName(WScript.ScriptFullName), "runas", 0
    If Err.Number <> 0 Then
        sh.Popup "Administrator approval is required to run SCCM maintenance." & vbCrLf & _
            vbCrLf & "By Ilyas Nazih", 0, "SCCMUpdate", 48
    End If
    On Error GoTo 0
    WScript.Quit
End If

bat = fso.BuildPath(fso.GetParentFolderName(WScript.ScriptFullName), "SCCMUpdate.bat")
If Not fso.FileExists(bat) Then
    sh.Popup "SCCMUpdate.bat was not found in this folder.", 0, "SCCMUpdate", 16
    WScript.Quit 11
End If

' Window style 0 = hidden; wait for the batch exit status before showing result.
cmd = q & sh.ExpandEnvironmentStrings("%ComSpec%") & q & " /d /c " & q & q & bat & q & " /silent" & q
rc = sh.Run(cmd, 0, True)

Select Case rc
    Case 0
        title = "SCCM Maintenance Completed"
        msg = "SCCM MAINTENANCE COMPLETE" & vbCrLf & vbCrLf & _
              "Local client maintenance and supported SCCM" & vbCrLf & _
              "refresh requests were executed successfully." & vbCrLf & _
              "SCCM continues processing queued work in the background." & vbCrLf
        style = 64
    Case 2
        title = "SCCM Maintenance - Warning"
        msg = "SCCM MAINTENANCE FINISHED WITH WARNINGS" & vbCrLf & vbCrLf & _
              "Some client actions could not be requested." & vbCrLf & _
              "Review the log before considering this laptop ready." & vbCrLf
        style = 48
    Case Else
        title = "SCCM Maintenance - Action Required"
        msg = "SCCM MAINTENANCE WAS NOT COMPLETED" & vbCrLf & vbCrLf & _
              "The local client needs administrator/IT attention." & vbCrLf & _
              "Exit code: " & CStr(rc) & vbCrLf
        style = 16
End Select

msg = msg & vbCrLf & "Log: %ProgramData%\SCCMUpdate\" & vbCrLf & vbCrLf & _
      "------------------------------" & vbCrLf & "By Ilyas Nazih  |  v2.0"
sh.Popup sh.ExpandEnvironmentStrings(msg), 0, title, style
WScript.Quit rc
